$(document).ready(function () {

	$('.addtocartBtn').click(function(){
		// alert('hello');

		getData();
		 	let id=$(this).data('id');
		 	let name=$(this).data('name');
		 	let price=$(this).data('price');
		 	let discount=$(this).data('discount');
		 	let img=$(this).data('img');
		 	
		 	let item={id:id,name:name,price:price,discount:discount,photo:img,qty:1};

		 	let oldcart=localStorage.getItem('cart');
		 	console.log(oldcart);
		 	if(oldcart==null){
				 var cart= new Array();
				
			}else{
				var cart = JSON.parse(oldcart);
				
			}
			var exist;
			$.each(cart, function(i,v) {
				if(id == v.id){
					v.qty++;
					exist = true;
			}		

			})
			if(!exist){
				cart.push(item);
			}
			localStorage.setItem('cart',JSON.stringify(cart));

			getData();
	})
		function getData(){
				var mycart = localStorage.getItem('cart');
				var data=$('#shoppingcart_table');
				var result ="";
				if(mycart !=null){
					cart = JSON.parse(mycart);
					var total=0;
					$.each(cart,function (i,v) {
						subtotal = v.price*v.qty;
						total+=subtotal;
						result +=`

						<tr>
						<td>${v.id}</td>
						<td><img src="${v.photo}"  width = '100'>${v.name}</td>
						<td>$ ${v.price}</td>
						<td><input type="number" value="${v.qty}" class="changeqty" data-id="${i}"></td>
						<td>${v.qty}</td>
						<td>${subtotal}</td>
						<td><button class='removebtn' data-id='${i}'>X</button></td>

						</tr>`;
										
					})
					result += `
							Total:
							${total}`;
						

				}else{
					result +='Cart is Empty;'
				}
				$('#shoppingcart_table').html(result);
		}

		$('#shoppingcart_table').on('click','.removebtn',function () {
							let index = $(this).data('id');
							var mycart = localStorage.getItem('cart');
							cart = JSON.parse(mycart);

							cart.splice(index,1);
							localStorage.setItem('cart',JSON.stringify(cart));
							getData();
						})
						


		$('#shoppingcart_table').on('click','.icofont-plus, .icofont-minus',function () {

			var qty=$(this).val();
							var val=parseFloat(qty.val());
							var max=parseFloat(qty.attr('max'));
							var min=parseFloat(qty.attr('min'));
							var step=parseFloat(qty.attr('step'));

							if($(this).is('.icofont-plus')){
								qty.val(val+step);
							}else{
								if(min && min >=val){
									qty.val(min);
								}else if (val>0) {
									qty.val(val-step);
									
								}
							}
							
						})

		$('#shoppingcart_table').on('change','.changeqty',function(){
							let qty=$(this).val();
							let index=$(this).data('id');

							var mycart=localStorage.getItem('cart');
							cart = JSON.parse(mycart);

							if(qty==0){
								cart.splice(index,1);
							}
							$.each(cart,function(i,v){
								if(i==index){
									v.qty=qty;
								}
							})
							localStorage.setItem('cart',JSON.stringify(cart));
							getData();

						})
					 })
			
